package com.tedu.mle.dao;

import com.tedu.mle.BaseTest;
import com.tedu.mle.entity.Shop;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

import static org.junit.Assert.*;

public class ShopDAOTest extends BaseTest {
    @Autowired
    ShopDAO shopDAO;

    @Test
    public void selectWithDiscount() {

    }//selectWithDiscountByCategory
    @Test
    public void selectWithDiscountByCategory() {

    }
}